/*	Simon Liu 
 *	COEN 177 Lab1 Tues 5:15
 *
 *	Description: Ouputs "Hello World" whenever the program is called
 *
 *	Test: 	gcc -o task1 task1.c
 *		runs through basic.c program
 */
#include <stdio.h>

int  main(){
	printf("Hello World\n");	//output "Hello World
	return 0;			//stops the program
}
